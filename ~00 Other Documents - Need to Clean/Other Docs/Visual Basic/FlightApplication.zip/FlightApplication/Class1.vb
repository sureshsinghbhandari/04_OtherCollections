﻿'Imports Microsoft.VisualBasic

Public cimaxConnection
Public cimaxRecordSet
Public cimaxCommand

'===============================================
'===============================================
'===============================================
'===============================================
'===============================================
'===============================================










'===============================================
'===============================================
'===============================================


'Search SQL Query, Including a Parameter Called Name
'This Query Simply Retrieves All Information That Matches Our Criteria

Dim strAccQuery As String = "SELECT Distinct Arrival from flights where Departure=@Name"
Dim strAccConn As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Testing\Documents\FlightApplication\FlightApplication.accdb"
Dim oleAccCon As OleDbConnection


'Instantiate Connection Object
oleAccCon = New OleDbConnection(strAccConn)

'Using Structure Simplifies Garbage Collection And Ensures That The Object Will Be Disposed Of Correctly Afterwards
Using oleAccCon

'Create Command Object, To Make Use Of SQL Query
Dim oleAccCommand As New OleDbCommand(strAccQuery, oleAccCon)

'Create Parameter Instead Of Hardcoding Values
'Name = Whatever txtSearch Contains
oleAccCommand.Parameters.AddWithValue("Name", sDepCity)

'Open Connection To The Database
oleAccCon.Open()






'Reader Object To Traverse Through Found Records
Dim oleAccReader As OleDbDataReader = oleAccCommand.ExecuteReader()

'If The Reader Finds Rows
If oleAccReader.HasRows Then

'Retrieve The Content, For Each Match
While oleAccReader.Read()

'GetString(1) Represents Column 2 Of StudentsInfo table
'                    txtName.Text = oleAccReader.GetString(1)

'GetString(2) Gets Information Stored In Third Column
'txtSurname.Text = oleAccReader.GetString(2)

'Use GetValue or GetInt32 Here, Because StudentNumber Is A Number Field
'txtStudentNumber.Text = oleAccReader.GetValue(0)
ComboBox2.Text = oleAccReader.GetValue(0)
End While

Else

'No Match Was Found
MessageBox.Show("No Rows Found.")

End If

'Close Reader Object
oleAccReader.Close()

End Using



'===============================================
'===============================================
'===============================================
'===============================================
'===============================================
'createCimaxCon
'
'Description: Open a connection to the Cimax Online database... need to rewrite this to use 
'			the Automation ODBC DSN
'===============================================
Private Sub createCimaxCon()

	Set cimaxConnection = CreateObject("ADODB.Connection")
	Set cimaxRecordSet = CreateObject("ADODB.Recordset")
	Set cimaxCommand = CreateObject("ADODB.Command")

	cimaxConnection.ConnectionString = "Provider=SQLOLEDB;Server=" & environmentString & "SQLR07.dvcorp.rcis.com,5208;Database=CIMAXOnline;UID=Automation;Pwd=G@t1td0ne"
    cimaxConnection.CursorLocation = 3 'adUseClient
    cimaxConnection.Open

End Sub

'===============================================
'closeCimaxCon
'
'Description: Close the Cimax Online database connection and set the connection objects to
'			nothing so there are no continued locks on the DB.
'===============================================
Sub closeCimaxCon()

    If typename(cimaxConnection) <> "Nothing" And typename(cimaxConnection) <> "Empty" Then
        cimaxConnection.Close
    End If
   
    Set cimaxConnection = Nothing
    Set cimaxRecordSet = Nothing
	Set cimaxCommand = nothing
End Sub

'===============================================
'fetchCimaxData
'
'Description: Connect to the Cimax Online database if you aren't already, then run a query that's designed
'			to return a single value and return the first result that comes back.
'Parameter: sqlStatement - This needs to be intelligently defined in the form of a string.
'Sample Usage: cropID = fetchCimaxData("select cropid from crop where CROPNM='" & inputCrop & "' and INSTYP=11")
'Note: Query should be functional in any query editor.  A multiple row response is acceptable, but only the first item in the first row will be returned.
'Returns: a string represented by the data in the first row and the first column of the recordset that resulted from the input query
'===============================================
Public Function fetchCimaxData(sqlStatement)

    If typename(cimaxConnection) = "Empty" Then
		Set cimaxConnection = nothing
	End If
    If cimaxConnection Is Nothing Then
        createCimaxCon()
    End If
    cimaxCommand.CommandText = sqlStatement
	'Set rstRecordSet = conConnection.Execute(sqlStatement)
	Set cimaxCommand.ActiveConnection = cimaxConnection
	cimaxCommand.CommandTimeout = 600
    cimaxCommand.CommandType = 1
    If Not (cimaxRecordSet Is Nothing) Then
        If cimaxRecordSet.State <> 0 Then
            cimaxRecordSet.Close
        End If
    End If
    With cimaxRecordSet
        .CursorType = 3
        .CursorLocation = 3
        .LockType = 1
        .Open cimaxCommand
    End With
    If Not (cimaxRecordSet Is Nothing) Then
        If cimaxRecordSet.State <> 0 Then
            If cimaxRecordSet.EOF = False Then
                cimaxRecordSet.MoveFirst
                fetchCimaxData = cimaxRecordSet(0).value
                cimaxRecordSet.close
                closeCimaxCon()
                Exit Function
            End If
        End If
    End If
    fetchCimaxData = ""
End Function

'===============================================
'fetchCimaxDataSet
'
'Description: Connect to the Cimax Online database if you aren't already, then run a query that's designed
'			to return a single value and return the first result that comes back.
'Parameter: sqlStatement - This needs to be intelligently defined in the form of a string.
'Sample Usage: cropID = fetchCimaxData("select cropid from crop where CROPNM='" & inputCrop & "' and INSTYP=11")
'Note: Query should be functional in any query editor.  A multiple row response is acceptable, but only the first item in the first row will be returned.
'Returns: a string represented by the data in the first row and the first column of the recordset that resulted from the input query
'===============================================
Public Function fetchCimaxDataSet(sqlStatement)

    If typename(cimaxConnection) = "Empty" Then
		Set cimaxConnection = nothing
	End If
    If cimaxConnection Is Nothing Then
        createCimaxCon()
    End If
    cimaxCommand.CommandText = sqlStatement
	Set cimaxCommand.ActiveConnection = cimaxConnection
	cimaxCommand.CommandTimeout = 600
    cimaxCommand.CommandType = 1
    If Not (cimaxRecordSet Is Nothing) Then
        If cimaxRecordSet.State <> 0 Then
            cimaxRecordSet.Close
        End If
    End If
    With cimaxRecordSet
        .CursorType = 3
        .CursorLocation = 3
        .LockType = 1
        .Open cimaxCommand
    End With
    If cimaxRecordSet.EOF = False Then
        cimaxRecordSet.MoveFirst
        set fetchCimaxDataSet = cimaxRecordSet
		Exit Function
    End If
	set fetchCimaxDataSet=nothing
End Function
'===============================================
'createInputCon
'
'Open a connection to an Access data file containing input test driver data.
'===============================================
Private Function createInputCon()

    Dim inputConnection
	Set inputConnection = CreateObject("ADODB.Connection")
    inputConnection.ConnectionString = "Provider=SQLOLEDB;Server=stsqlr10.dvcorp.rcis.com,5208;Database=AutomationLPT;UID=Automation;Pwd=G@t1td0ne"
    inputConnection.CursorLocation = 3 'adUseClient
    inputConnection.Open

	Set createInputCon = inputConnection
End Function

'===============================================
'closeInputCon
'
'Description: Close the Cimax Online database connection and set the connection objects to
'			nothing so there are no continued locks on the DB.
'===============================================
Private Sub closeInputCon(inputConnection)

    If typename(inputConnection) <> "Nothing" Then
        inputConnection.Close
    End If
    Set inputConnection = Nothing
End Sub
