﻿Imports System.Data.OleDb
Public Class Form1
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "This is My Application - Suresh Bhandari"
        Me.MonthCalendar1.Hide()
        Dim myConnToAccess As OleDbConnection
        Dim ds As DataSet
        Dim da As OleDbDataAdapter
        Dim tables As DataTableCollection
        myConnToAccess = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Testing\Documents\FlightApplication\FlightApplication.accdb")
        myConnToAccess.Open()
        ds = New DataSet
        tables = ds.Tables
        da = New OleDbDataAdapter("SELECT Distinct Departure from flights  order by 1", myConnToAccess)
        da.Fill(ds, "Items")
        Dim view1 As New DataView(tables(0))
        With ComboBox1
            .DataSource = ds.Tables("Items")
            .DisplayMember = "Departure"
            .ValueMember = "Departure"
            .SelectedIndex = 0
            .AutoCompleteMode = AutoCompleteMode.SuggestAppend
            .AutoCompleteSource = AutoCompleteSource.ListItems
        End With


    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim sDepCity As String = ComboBox1.SelectedValue.ToString

        If Len(Trim(sDepCity)) = 0 Then
            Exit Sub
        End If
        Dim myConnToAccess As OleDbConnection
        Dim ds As DataSet
        Dim da As OleDbDataAdapter
        Dim tables As DataTableCollection
        myConnToAccess = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Testing\Documents\FlightApplication\FlightApplication.accdb")
        myConnToAccess.Open()
        ds = New DataSet
        tables = ds.Tables
        da = New OleDbDataAdapter("SELECT Distinct Arrival from flights where Departure='" + sDepCity + "' order by 1", myConnToAccess)
        da.Fill(ds, "Items")



        '***********************************************************************************************************
        '***********************************************************************************************************
        '***********************************************************************************************************
        '***********************************************************************************************************
        '***********************************************************************************************************




        '***********************************************************************************************************
        '***********************************************************************************************************
        '***********************************************************************************************************
        '***********************************************************************************************************
        '***********************************************************************************************************


        If ds.Tables("Items").Rows.Count > 1 Then
            With ComboBox2
                .DataSource = ds.Tables("Items")
                .DisplayMember = "Arrival"
                .ValueMember = "Arrival"
                .AutoCompleteMode = AutoCompleteMode.SuggestAppend
                .AutoCompleteSource = AutoCompleteSource.ListItems
            End With
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button4.Click
        Dim verifyFirstValidation As Boolean = False
        If Len(Trim(TextBox1.Text)) <= 0 Then
            MsgBox("Kindly Enter Date, Without Date we can't proceed")
        ElseIf Len(Trim(ComboBox1.Text)) <= 0 Then
            MsgBox("Kindly Enter Fly From, Without Departure Airport we can't proceed")
        ElseIf Len(Trim(ComboBox2.Text)) <= 0 Then
            MsgBox("Kindly Enter Fly From, Without Arrival Airport we can't proceed")
        Else
            Form2.ShowDialog(Me)
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Me.MonthCalendar1.Visible = True
        MonthCalendar1.TitleBackColor = System.Drawing.Color.Blue
        MonthCalendar1.TrailingForeColor = System.Drawing.Color.Red
        MonthCalendar1.TitleForeColor = System.Drawing.Color.Yellow

        MonthCalendar1.BringToFront()

        ' Configure the calendar to display 3 rows by 4 columns of months.
        MonthCalendar1.CalendarDimensions = New System.Drawing.Size(4, 3)

        ' Set the week to begin on Monday.
        MonthCalendar1.FirstDayOfWeek = System.Windows.Forms.Day.Monday

        ' Set the calendar to move one month at a time when navigating using the arrows.
        MonthCalendar1.ScrollChange = 1

        ' Do not show the "Today" banner.
        MonthCalendar1.ShowToday = True

        ' Do not circle today's date.
        MonthCalendar1.ShowTodayCircle = True

        ' Show the week numbers to the left of each week.
        MonthCalendar1.ShowWeekNumbers = True


    End Sub

    'Private Sub MonthCalendar1_DateChanged(sender As Object, e As DateRangeEventArgs) Handles MonthCalendar1.DateChanged
    '    Me.TextBox1.Text = MonthCalendar1.SelectionStart.ToShortDateString
    '    MonthCalendar1.Hide()
    'End Sub



    Private Sub monthCalendar1_DateSelected(ByVal sender As Object,
                ByVal e As System.Windows.Forms.DateRangeEventArgs) Handles MonthCalendar1.DateSelected

        ' Show the start and end dates in the text box.
        TextBox1.Text = e.Start.ToShortDateString() '+ " : End = " + e.End.ToShortDateString()
        MonthCalendar1.Hide()
    End Sub

    Private Sub monthCalendar1_DateChanged(ByVal sender As Object,
                    ByVal e As System.Windows.Forms.DateRangeEventArgs) Handles MonthCalendar1.DateChanged

        ' Show the start and end dates in the text box.
        TextBox1.Text = e.Start.ToShortDateString() '+ " : End = " + e.End.ToShortDateString()
        MonthCalendar1.Hide()
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked Then
            Me.TextBox8.Text = PriceClassSelection("First")
        End If
        updateTotalAmount(True)
    End Sub
    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked Then
            Me.TextBox8.Text = PriceClassSelection("Business")
        End If
        updateTotalAmount(True)
    End Sub
    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        If RadioButton3.Checked Then
            Me.TextBox8.Text = PriceClassSelection("Economy")
        End If
        updateTotalAmount(True)
    End Sub


    Public Function PriceClassSelection(PriceClass As String) As String
        Dim sFlightNumber As String = Me.TextBox2.Text.ToString
        Dim myConnToAccess As OleDbConnection
        Dim ds As DataSet
        Dim da As OleDbDataAdapter
        Dim tables As DataTableCollection
        myConnToAccess = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Testing\Documents\FlightApplication\FlightApplication.accdb")
        myConnToAccess.Open()
        ds = New DataSet
        tables = ds.Tables
        da = New OleDbDataAdapter("SELECT TicketPrice from flights where FlightNumber=" + sFlightNumber, myConnToAccess)
        da.Fill(ds, "Items")
        Dim view1 As New DataView(tables(0))
        Dim tempTicketPrice As Double
        tempTicketPrice = view1.Item(0).Row.Item("TicketPrice")

        Dim tempItemPrice As Double
        Select Case PriceClass
            Case "First"
                tempItemPrice = 1.5
            Case "Business"
                tempItemPrice = 2.0
            Case "Economy"
                tempItemPrice = 1.0
        End Select
        Dim TotalAmount As Double
        TotalAmount = tempTicketPrice * tempItemPrice
        Return TotalAmount.ToString
    End Function


    Public Function updateTotalAmount(UpdateTotal As Boolean) As String
        Dim iNoOfTickets As Integer
        If UpdateTotal Then
            If Len(Me.TextBox7.Text) = 0 Then
                Exit Function
            Else
                iNoOfTickets = Me.TextBox7.Text
            End If
            Dim iTextBoxPrice As Double = CType(Me.TextBox8.Text, Double)
            Dim iTotalPrice As Double = iNoOfTickets * iTextBoxPrice
            Me.TextBox9.Text = iTotalPrice.ToString
            Return iTotalPrice.ToString
        End If
    End Function

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs) Handles TextBox7.TextChanged
        If Len(Trim(Me.TextBox7.Text)) > 0 Then
            Me.TextBox9.Text = updateTotalAmount(True).ToString
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'Insert Order 

    End Sub
End Class




