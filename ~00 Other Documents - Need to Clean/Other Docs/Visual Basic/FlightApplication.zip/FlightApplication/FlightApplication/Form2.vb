﻿Imports System.Data.Common
Imports System.Data.OleDb
Imports Microsoft.VisualBasic

Public Class Form2
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "This is My Select Flight - Suresh Bhandari"

        Dim sDepCity As String = Form1.ComboBox1.SelectedValue.ToString
        Dim sArivalCity As String = Form1.ComboBox2.SelectedValue.ToString
        Dim WeekOfDay As String = CDate(Form1.TextBox1.Text).DayOfWeek.ToString

        'Set the selection mode to multiple and extended.
        'ListBox1.SelectionMode = SelectionMode.MultiExtended

        ListBox1.FormattingEnabled = True
        ListBox1.HorizontalScrollbar = True
        ListBox1.MultiColumn = True
        ListBox1.ScrollAlwaysVisible = True
        ListBox1.TabIndex = 0
        ListBox1.ColumnWidth = 200


        ' Set the view to show details.
        ListView1.View = View.Details
        ' Allow the user to edit item text.
        ListView1.LabelEdit = True
        ' Allow the user to rearrange columns.
        ListView1.AllowColumnReorder = True
        ' Display check boxes.
        ListView1.CheckBoxes = False
        ' Select the item and subitems when selection is made.
        ListView1.FullRowSelect = True
        ' Display grid lines.
        ListView1.GridLines = True
        ' Sort the items in the list in ascending order.
        ListView1.Sorting = SortOrder.Ascending

        ListView1.Columns.Add("FlightNumber", 85)
        ListView1.Columns.Add("Departure Airport", 85)
        ListView1.Columns.Add("Departure Time", 85)
        ListView1.Columns.Add("Arrival Airport", 85)
        ListView1.Columns.Add("Arrival Time", 85)
        ListView1.Columns.Add("Airline", 85)


        Dim myConnToAccess As OleDbConnection
        Dim ds As DataSet
        Dim da As OleDbDataAdapter
        Dim tables As DataTableCollection
        myConnToAccess = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Testing\Documents\FlightApplication\FlightApplication.accdb")
        myConnToAccess.Open()
        ds = New DataSet
        tables = ds.Tables
        da = New OleDbDataAdapter("SELECT FlightNumber, Departure, DepartureTime, Arrival, ArrivalTime, Airline, TicketPrice from flights where Departure='" + sDepCity + "' and Arrival='" + sArivalCity + "' and DayOfWeek='" + WeekOfDay + "' order by 1,2,3,4,5,6", myConnToAccess)
        da.Fill(ds, "Items")
        Dim view1 As New DataView(tables(0))

        'Add items in the listview
        Dim arr(5) As String
        Dim itm As ListViewItem
        Dim x As Integer
        Dim templist As String
        templist = ""
        If Not (view1.Count = 0) Then
            For x = 0 To view1.Count - 1
                arr(0) = view1.Item(x).Item(0).ToString
                arr(1) = view1.Item(x).Item(1).ToString
                arr(2) = Convert.ToDateTime(view1.Item(x).Item(2)).ToString("t")
                arr(3) = view1.Item(x).Item(3).ToString
                arr(4) = Convert.ToDateTime(view1.Item(x).Item(4)).ToString("t")
                arr(5) = view1.Item(x).Item(5).ToString
                itm = New ListViewItem(arr)
                ListView1.Items.Add(itm)
            Next x
        End If

        templist = view1.Item(x).Item(0).ToString + vbTab + view1.Item(x).Item(1).ToString + vbTab + Convert.ToDateTime(view1.Item(x).Item(2)).ToString("t") + vbTab + "To" + vbTab + view1.Item(x).Item(3).ToString + vbTab + Convert.ToDateTime(view1.Item(x).Item(4)).ToString("t") + vbTab + vbTab + view1.Item(x).Item(5).ToString

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If MsgBox("Are you sure that you want to close this form?", vbYesNo) = vbYes Then
            Me.Close()
            Exit Sub
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim sFlightNumber As String = ListView1.SelectedItems.Item(0).SubItems(0).Text
        Dim sDepartureAirport As String = ListView1.SelectedItems.Item(0).SubItems(1).Text
        Dim sDepartureTime As String = ListView1.SelectedItems.Item(0).SubItems(2).Text
        Dim sArrivalAirport As String = ListView1.SelectedItems.Item(0).SubItems(3).Text
        Dim sArrivalTime As String = ListView1.SelectedItems.Item(0).SubItems(4).Text
        Dim sAirline As String = ListView1.SelectedItems.Item(0).SubItems(5).Text

        Me.Close()

        Form1.TextBox2.Text = sFlightNumber
        Form1.TextBox3.Text = sDepartureTime
        Form1.TextBox4.Text = sArrivalTime
        Form1.TextBox5.Text = sAirline

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ListView1.Clear()
    End Sub
End Class