
## Test automation framework powered by Selenium Webdriver
=========

Requirements:

    ruby-1.9.3
    selenium-webdriver (>=2.26.0)
    test-unit (>=2.5.3)

Sample test run: looking for "cheese" on Google

    LOCAL_RUN=true ruby integration_tests.rb 
         

