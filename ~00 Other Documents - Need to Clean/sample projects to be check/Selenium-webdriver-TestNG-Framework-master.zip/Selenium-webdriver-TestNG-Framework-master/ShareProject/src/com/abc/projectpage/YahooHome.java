package com.abc.projectpage;


/**
 * 
 * @author somasish
 *This class is for Showing a Page object modeling and Not for Testing
 */
public class YahooHome {

}
