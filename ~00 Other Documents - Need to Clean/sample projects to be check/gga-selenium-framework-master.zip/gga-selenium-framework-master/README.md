#GGA Selenium Framework#

Copyright (c) 2014 GGA Software Services LLC

##Introduction##

This software was developed for automation testing using Selenium WebDriver and Java. 
It based on Maven structure and integrating with TestNG testing framework.

For more details please visit
http://lifescience.opensource.epam.com/selenium.html

##License##

The source code is licensed under GPL v3. [GPL License](http://www.gnu.org/licenses).
