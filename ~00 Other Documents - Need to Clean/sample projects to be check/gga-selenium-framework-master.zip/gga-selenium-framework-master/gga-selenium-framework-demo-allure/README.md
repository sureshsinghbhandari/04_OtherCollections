##GGA Selenium Framework Demo - Allure##

Small demonstration maven project, which contains test structure to run tests and generate html report.   

For more details please visit 

http://lifescience.opensource.epam.com/selenium.html

For generate report use Allure Command Line Tool:

https://github.com/allure-framework/allure-cli