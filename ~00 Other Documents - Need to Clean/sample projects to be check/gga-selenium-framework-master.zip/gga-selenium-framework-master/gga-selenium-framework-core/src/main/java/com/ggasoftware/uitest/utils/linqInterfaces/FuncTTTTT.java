package com.ggasoftware.uitest.utils.linqInterfaces;

/**
 * Created by roman.i on 01.10.2014.
 */
public interface FuncTTTTT<T1, T2, T3, T4, T> {
    T invoke(T1 val1, T2 val2, T3 val3, T4 val4) throws Exception;
}
