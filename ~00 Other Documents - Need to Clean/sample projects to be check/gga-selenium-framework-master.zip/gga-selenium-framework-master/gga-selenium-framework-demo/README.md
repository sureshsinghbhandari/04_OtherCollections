##GGA Selenium Framework Demo##

Small demonstration maven project, which contains test structure to run tests and generate html report.

For more details please visit

http://lifescience.opensource.epam.com/selenium.html