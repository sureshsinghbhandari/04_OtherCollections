pref("extensions.{3d7eb24f-2740-49df-8937-200b1cc08f8a}.description", "chrome://flashblock/locale/flashblock.properties");
pref("flashblock.enabled",false);
pref("flashblock.whitelist", "");
pref("flashblock.blockLocal",false);
pref("browser.toolbars.showbutton.flashblockMozToggle", false);
pref("flashblock.silverlight.blocked",false);
pref("flashblock.java.blocked",false);
