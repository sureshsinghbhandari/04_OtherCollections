package testCases;

import moduleActions.SignIn_Action;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageObjects.Home_Page;
import pageObjects.LogIn_Page;
import utility.Constant;
import utility.ExcelUtils;
import utility.Log;

import java.io.IOException;

/**
 * Created by wzunix on 28/04/15.
 */
public class POM_TC {
    private static WebDriver driver = null;

    public static void main(String[] args) throws IOException {
        //Provide Log4j configuration settings
        DOMConfigurator.configure("./src/main/resources/log4j.xml");
        Log.startTestCase("Selenium Test 001");

        ExcelUtils.setExcelFile(Constant.Path_TestData + Constant.File_TestData, "Test1");
        Log.info("Open Excel file: " + Constant.Path_TestData + Constant.File_TestData);

        driver = new FirefoxDriver();
        Log.info("New driver instantiated");

        driver.get(Constant.URL);
        Log.info("Application launched");

        SignIn_Action.Execute(driver);
        Log.info("Login Successfully");

        new WebDriverWait(driver,10).until(ExpectedConditions.presenceOfElementLocated(
                           By.xpath("//*[text()=\"Log out\"]")));

        Home_Page.lnk_LogOut(driver).click();
        Log.info("Click action performed on LogOut link");

        ExcelUtils.setCellData("Pass",3,3);

        driver.quit();
        Log.sEndTestCase("Selenium Test 001");
    }
}
