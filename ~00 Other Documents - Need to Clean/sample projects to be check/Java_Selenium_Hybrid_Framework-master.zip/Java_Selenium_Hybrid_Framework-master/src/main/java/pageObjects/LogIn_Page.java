package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import utility.Log;

/**
 * Created by wzunix on 28/04/15.
 */
public class LogIn_Page {
    private static WebElement element = null;

    public static WebElement txtbx_UserName(WebDriver driver){
        element = driver.findElement(By.cssSelector("#log"));
        Log.info("LogIn_Page - UserName Element found");
        return element;
    }

    public static WebElement txtbx_Password(WebDriver driver){
        element = driver.findElement(By.cssSelector("#pwd"));
        Log.info("LogIn_Page - Password Element found");
        return element;
    }

    public static WebElement btn_LogIn(WebDriver driver){
        element = driver.findElement(By.cssSelector("#login"));
        Log.info("Login_Page - LogIn Button found");
        return element;
    }
}
