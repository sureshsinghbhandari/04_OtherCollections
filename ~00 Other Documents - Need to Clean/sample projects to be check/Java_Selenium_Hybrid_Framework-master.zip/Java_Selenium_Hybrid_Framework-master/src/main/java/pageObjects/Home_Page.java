package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import utility.Log;

import java.util.concurrent.TimeUnit;

/**
 * Created by wzunix on 28/04/15.
 */
public class Home_Page {
    private static WebElement element = null;

    public static WebElement lnk_MyAccount(WebDriver driver){

        element = driver.findElement(By.cssSelector(".account_icon"));
        Log.info("My Account Element found");
        return element;
    }

    public static WebElement lnk_LogOut(WebDriver driver){
        element = driver.findElement(By.xpath("//*[text()=\"Log out\"]"));
        Log.info("LogOut Element found");
        return element;
    }
}
