package moduleActions;

import org.openqa.selenium.WebDriver;
import pageObjects.Home_Page;
import pageObjects.LogIn_Page;
import utility.ExcelUtils;
import utility.Log;

/**
 * Created by wzunix on 29/04/15.
 */
public class SignIn_Action {
    public static void Execute(WebDriver driver){

        String userName = ExcelUtils.getCellData(3,1);
        Log.info("User Name picked up from excel is: " + userName);
        String password = ExcelUtils.getCellData(3,2);
        Log.info("Password picked up from excel is: " + password );

     /*   Click on the My Account link.
        Enter Username
        Enter Password
        Click on the Submit button
     */
        Home_Page.lnk_MyAccount(driver).click();
        Log.info("Click action performed on My Account link");

        LogIn_Page.txtbx_UserName(driver).sendKeys(userName);
        Log.info("User name entered in the UserName text box");

        LogIn_Page.txtbx_Password(driver).sendKeys(password);
        Log.info("Password entered in the Password text box");

        LogIn_Page.btn_LogIn(driver).click();
        Log.info("Click action performed on LogIn button");
     }
}
