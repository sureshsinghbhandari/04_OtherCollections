package utility;

/**
 * Created by wzunix on 29/04/15.
 */
public class Constant {
    public static final String URL = "http://www.store.demoqa.com";
    public static final String Username = "testuser_wz";
    public static final String Password = "Test@wz";

    public static final String Path_TestData = "/Users/wzunix/IdeaProjects/Hybrid_Framework/src/main/java/testData/";
    public static final String File_TestData = "TestData.xlsx";
}
