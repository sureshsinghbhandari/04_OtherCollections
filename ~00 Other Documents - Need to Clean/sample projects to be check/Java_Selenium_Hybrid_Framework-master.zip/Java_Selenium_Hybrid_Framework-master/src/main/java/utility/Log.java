package utility;


import org.apache.log4j.Logger;

/**
 * Created by wzunix on 01/05/15.
 */
public class Log {
    //Initialize log4j logs
    private static Logger Log = Logger.getLogger(Log.class.getName());

    // This is to print log for the beginning of the test case, as we usually run so many test cases as a test suite
    public static void startTestCase(String sTestCaseName){
        Log.info("**********************************************************");
        Log.info("**********************************************************");
        Log.info("$$$$$$$$$$$$$$$$$" + sTestCaseName +"$$$$$$$$$$$$$$$$$$$$$");
        Log.info("**********************************************************");
        Log.info("**********************************************************");
    }

    // This is to print log for end of test case
    public static void sEndTestCase(String sTestCaseName){
        Log.info("#######################" + " --E--N--D--"+"###############");
        Log.info("#");
        Log.info("#");
        Log.info("#");
        Log.info("#");
    }
    // Create these methods, so that they can be called
    public static void info(String msg){
        Log.info(msg);
    }
    public static void warn(String msg){
        Log.warn(msg);
    }
    public static void error(String msg){
        Log.error(msg);
    }
    public static void fatal(String msg){
        Log.fatal(msg);
    }
    public static void debug(String msg){
        Log.debug(msg);
    }
}
