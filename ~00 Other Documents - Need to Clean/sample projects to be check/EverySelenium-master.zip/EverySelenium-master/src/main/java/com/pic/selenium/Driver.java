package com.pic.selenium;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

import java.io.File;

public class Driver {

    private WebDriver driver;

    public Driver(){
        //We are using firefox version 29 for testing.
        FirefoxBinary binary = new FirefoxBinary(new File("C:\\autotest_firefox_v29\\firefox.exe"));
        FirefoxProfile profile = new FirefoxProfile();

        driver = new FirefoxDriver(binary,profile);
    }
    public WebDriver getDriver(){
        return driver;
    }
}
