package com.pic.selenium.locate_element;

/*

We might not need this file, will come back later to confirm.

 */
import com.pic.selenium.Driver;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Locate_By_Text_Contents {

    private static WebDriver driver;
    private static WebElement g_search_txt;
    private static WebElement g_search_btn;

    @BeforeClass
    public static void setup(){
        driver = new Driver().getDriver();
    }
    @AfterClass
    public static void tearDown(){
        driver.quit();
    }
    @Before
    public void beforeTest(){
        driver.get("https://www.google.ie");
        g_search_txt = null;
        g_search_btn = null;
    }
 /*   @Test
    public void cssSelect_by_text_contents(){
        // Use cssSelector to locate the search button with it's displayed text "Google Search"
        g_search_txt = driver.findElement(By.cssSelector("input[name='q']"));
        g_search_btn = driver.findElement(By.cssSelector("button[textContent='Google Search']"));

        g_search_txt.sendKeys("selenium");
        g_search_btn.click();
    }  */
}
