package com.pic.selenium.locate_element;

import com.pic.selenium.Driver;
import junit.framework.*;
import junit.framework.Assert;
import org.junit.*;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

import static junit.framework.Assert.assertEquals;
import static junit.framework.TestCase.assertTrue;

public class Locate_By_Examples {

    private static WebDriver driver;
    private static WebElement g_search_item;
    private static WebElement g_search_txt;
    private static WebElement g_search_btn;
    private static WebElement result;

    @BeforeClass
    public static void setup(){
        driver = new Driver().getDriver();
    }
    @AfterClass
    public static void tearDown(){
        driver.quit();
    }
    @Before
    public void reset_page(){
        driver.get("http://docs.seleniumhq.org/");
        new WebDriverWait(driver, 10).until(ExpectedConditions.titleContains("Selenium - Web Browser Automation"));
        g_search_item = null;
        g_search_txt = null;
        g_search_btn = null;
        result = null;
    }
    @Test
    public void search_by_id(){
        //Find About menu by its id
        //<li id="menu_about">
        g_search_item = driver.findElement(By.id("menu_about"));
        g_search_item.click();

        do_wait("AboutPage");
       // do_assert("Title");
    }
    @Test
    public void search_by_name(){
        //<input id="q" type="text" size="30" accesskey="s" name="q">
        g_search_txt = driver.findElement(By.name("q"));
        g_search_txt.sendKeys("webdriver");

        //<input id="submit" type="submit" value="Go">
        g_search_btn = driver.findElement(By.id("submit"));
        g_search_btn.submit();
        do_wait("SearchPage");
    //    do_assert();
    }
    @Test
    public void search_by_tagName(){
        // Should use findElements while locating elements with tag names.
        //There're 7 <input> tags, the search input is the 3rd one
        List<WebElement> inputs = driver.findElements(By.tagName("input"));
        System.out.println("There're " + inputs.size() + " buttons on the page.");
        //There're 7 <input> tags, the search input is the 3rd one
        inputs.get(2).sendKeys("webdriver");

        //<input id="submit" type="submit" value="Go">
        g_search_btn = driver.findElement(By.id("submit"));
        g_search_btn.submit();
        do_wait("SearchPage");
 //       do_assert();

    }
    @Test
    public void search_by_className(){
        //<div class="downloadBox">
        g_search_txt = driver.findElement(By.className("downloadBox"));

        assertTrue("Checking DownloadBox contents: ",g_search_txt.getText().toString().contentEquals("Download Selenium"));
    }
    @Test
    public void search_by_linkText(){
        //Note: The HTML link elements are represented on a web page using the <a> tag, abbreviation for the anchor tag.
        //<a href="/support/">Support</a>
        WebElement g_about_lnk = driver.findElement(By.linkText("Support"));
        g_about_lnk.click();
        //Wait page to be loaded before assertion
        do_wait("SupportPage");
    }
    @Test
    public void search_by_partialLinkText(){
        //<a href="/about/">About Selenium</a>
        WebElement g_search_pLnk = driver.findElement(By.partialLinkText("About Se"));
        g_search_pLnk.click();

       do_wait("AboutPage");
    }
    @Test
    public void search_by_xpath(){
        // .//*[@id='menu_about']/a
        WebElement g_apps_lnk = driver.findElement(By.xpath(".//*[@id='menu_about']/a"));
        g_apps_lnk.click();
        do_wait("AboutPage");
    }
    @Test
    public void search_by_cssSelector(){
        //<input id="q" type="text" size="30" accesskey="s" name="q"/>
        g_search_txt = driver.findElement(By.cssSelector("#q"));
        g_search_txt.sendKeys("selenium");
        //<input id="submit" type="submit" value="Go"/>
        g_search_btn = driver.findElement(By.cssSelector("#submit"));
        g_search_btn.click();
        do_wait("SearchPage");
      //  do_assert();
    }
    private void do_wait(String title){
        String page_title = null;
        if(title == "AboutPage"){
            page_title = "About Selenium";
        }else if(title == "SupportPage"){
            page_title = "Getting Help";
        }else if(title == "SearchPage"){
            page_title = "Google Custom Search";
        }else{
            System.out.println("Page '" + title + "' has not been added in yet." );
        }
        //Wait until URL redirect to correct page
        new WebDriverWait(driver, 10).until(ExpectedConditions.titleContains(page_title));
        System.out.println("Loaded Page Title: " + page_title);
    }
    private void do_assert() {
        //<div id="resultStats"> About 374 results </div>
        result = driver.findElement(By.id("resultStats"));
        System.out.println("Returned result is: \"" + result.getText().toString()+"\"");
        assertTrue("Returned '"+ result.getText().toString() +"' results",result.getText().toString().contains(result.getText().toString()));
    }

}