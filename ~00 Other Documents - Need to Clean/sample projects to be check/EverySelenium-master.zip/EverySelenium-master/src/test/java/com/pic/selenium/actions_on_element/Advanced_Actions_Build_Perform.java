package com.pic.selenium.actions_on_element;

import com.pic.selenium.Driver;
import org.junit.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

import static junit.framework.Assert.assertTrue;

public class Advanced_Actions_Build_Perform {
    private static WebDriver driver;
    private static WebElement multi_select_itm1;
    private static WebElement multi_select_itm2;
    private static WebElement multi_select_itm3;
    private static WebElement multi_select_itm4;

    @BeforeClass
    public static void setup(){
        driver = new Driver().getDriver();
    }
    @Before
    public void beforeTest(){
        driver.get("http://compendiumdev.co.uk/selenium/basic_html_form.html");
        new WebDriverWait(driver,10).until(ExpectedConditions.titleContains("HTML Form Elements"));
        multi_select_itm1 = driver.findElement(By.cssSelector("option[value='ms1']"));
        multi_select_itm2 = driver.findElement(By.cssSelector("option[value='ms2']"));
        multi_select_itm3 = driver.findElement(By.cssSelector("option[value='ms3']"));
        multi_select_itm4 = driver.findElement(By.cssSelector("option[value='ms4']"));
    }
    @After
    public void afterTest(){
        multi_select_itm1 = null;
        multi_select_itm2 = null;
        multi_select_itm3 = null;
        multi_select_itm4 = null;
    }
    @AfterClass
    public static void tearDown(){
        driver.quit();
    }
    @Test
    public void actions_Builder_Perform_Test(){
        // Gather a series Actions
        Actions builder = new Actions(driver);
        builder.keyDown(Keys.CONTROL)
                .click(multi_select_itm1)
                .click(multi_select_itm3)
                .click(multi_select_itm4)
                .keyUp(Keys.CONTROL);
        //Build the composite Action
        Action compositeAction = builder.build();
        // Perform the Composite Action
        compositeAction.perform();
  //      new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeSelected(multi_select_itm1));
    //    new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeSelected(multi_select_itm3));
        new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeSelected(multi_select_itm4));

        //Submit the form, accomplished by submit any element within the form.
        driver.findElement(By.cssSelector("input[type='submit']")).click();
        new WebDriverWait(driver,10).until(ExpectedConditions.titleContains("Processed Form Details"));
      // assertTrue(driver.findElement(By.cssSelector("#_multipleselect > ul :nth-child(1)")).getText().equals("ms1"));
     //   assertTrue(driver.findElement(By.cssSelector("#_multipleselect > ul :nth-child(2)")).getText().equals("ms3"));
        assertTrue(driver.findElement(By.cssSelector("#_multipleselect > ul :nth-last-child(1)")).getText().toString().contains("ms4"));




    }




}
