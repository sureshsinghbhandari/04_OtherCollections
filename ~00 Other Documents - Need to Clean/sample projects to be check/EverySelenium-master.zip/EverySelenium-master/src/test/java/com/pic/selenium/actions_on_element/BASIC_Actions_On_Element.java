package com.pic.selenium.actions_on_element;

import com.pic.selenium.Driver;
import org.junit.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.junit.Assert.assertTrue;

public class BASIC_Actions_On_Element {
    private static WebDriver driver;
    private static WebElement g_search_txt;
    private static WebElement g_search_btn;
    private static WebElement g_search_form;

    @BeforeClass
    public static void setup(){
        driver = new Driver().getDriver();
    }
    @AfterClass
    public static void tearDown(){
        driver.quit();
    }
    @Before
    public void before_test(){
        driver.get("https://www.google.ie/?gws_rd=ssl");
    }
    @After
    public void after_test(){
        g_search_txt = null;
        g_search_btn = null;
        g_search_form = null;
    }
    @Test
    public void getAttribute_test(){
        // This test is to printing out all attributes of 'Google Search' button.
        //<button id="gbqfba" class="gbqfba" name="btnK" aria-label="Google Search">
        g_search_btn  = driver.findElement(By.cssSelector("button[name='btnK']"));
        System.out.println("Name of the button is: " +g_search_btn.getAttribute("name"));
        System.out.println("Id of the button is: " +g_search_btn.getAttribute("id"));
        System.out.println("Class of the button is: " +g_search_btn.getAttribute("class"));
        System.out.println("Label of the button is: " +g_search_btn.getAttribute("aria-label"));
    }
    @Test
    public void sendKeys_Test(){
        g_search_txt = driver.findElement(By.cssSelector("input[type='text'][name='q']"));
        g_search_txt.sendKeys("selenium");
        g_search_btn = driver.findElement(By.cssSelector("button[name='btnG']"));
        g_search_btn.click();
        new WebDriverWait(driver,10).until(ExpectedConditions.titleContains("selenium"));

        assertTrue(driver.findElement(By.cssSelector("a[href*='http://www.seleniumhq.org']")).isEnabled());
    }
    @Test
    public void clear_Test(){
        g_search_txt = driver.findElement(By.cssSelector("input[name='q']"));
        // Search 'SELENIUM' in google search
        g_search_txt.sendKeys(Keys.chord(Keys.LEFT_SHIFT,"selenium"));
        new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[name='btnG']")));
        g_search_btn = driver.findElement(By.cssSelector("button[name='btnG']"));
        g_search_btn.click();
        new WebDriverWait(driver,10).until(ExpectedConditions.titleContains("SELENIUM"));

        System.out.println("Current PageTitle is: " + driver.getTitle().toString());
        g_search_txt.clear();
        g_search_txt.sendKeys("wzunix");
        g_search_btn.click();
        new WebDriverWait(driver,10).until(ExpectedConditions.titleContains("wzunix"));
        System.out.println("Current PageTitle is: "+driver.getTitle().toString());
    }
    @Test
    public void submit_Test(){
        g_search_txt = driver.findElement(By.cssSelector("input[name='q']"));
        // Search 'SELENIUM' in google search
        g_search_txt.sendKeys(Keys.chord(Keys.LEFT_SHIFT,"selenium"));
   //     new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[name='btnG']")));
   //     g_search_btn = driver.findElement(By.cssSelector("button[name='btnG']"));
        g_search_form = driver.findElement(By.cssSelector("form[name='gbqf']"));
        g_search_form.submit();
        new WebDriverWait(driver,10).until(ExpectedConditions.titleContains("SELENIUM"));

        System.out.println("Current PageTitle is: "+driver.getTitle().toString());
        g_search_txt.clear();
        g_search_txt.sendKeys("wzunix");
        g_search_txt.submit();
   //OR     g_search_btn.submit();
   //OR     g_search_form.submit();
        new WebDriverWait(driver,10).until(ExpectedConditions.titleContains("wzunix"));
        System.out.println("Current PageTitle is: "+driver.getTitle().toString());
    }
    @Test
    public void getCssValue_Test(){
        //input id="gbqfq" class="gbqfif" type="text" value="" autocomplete="off" name="q" aria-haspopup="false" role="combobox" aria-autocomplete="both" style="border: medium none; padding: 0px; margin: 0px; height: auto; width: 100%; background: url("data:image/gif;base64,R0lGODlhAQABAID/AMDAwAAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw%3D%3D") repeat scroll 0% 0% transparent; position: absolute; z-index: 6; left: 0px; outline: medium none;" dir="ltr" spellcheck="false">
        g_search_txt = driver.findElement(By.cssSelector("input[name='q']"));
        System.out.println("Search_field's font-family value is: " + g_search_txt.getCssValue("font-family"));
    }
    @Test
    public void getLocation_Test(){
        g_search_txt = driver.findElement(By.cssSelector("input[name='q']"));
        System.out.println("Google Search txt field location on Page is: " + g_search_txt.getLocation());
    }
    @Test
    public void getSize_Test(){
        g_search_txt = driver.findElement(By.cssSelector("input[name='q']"));
        System.out.println("Google Search txt field size is: " + g_search_txt.getSize());
    }
    @Test
    public void getText_Test(){
        g_search_txt = driver.findElement(By.cssSelector("input[name='q']"));
        String g_search_txt_field = g_search_txt.getText();
        if (g_search_txt_field.length() > 0){
            System.out.println("Google Search Text Field's text is: " + g_search_txt.getText());
        }else {
            System.out.println("Google Search Text Field's text is: <null>");
        }

        g_search_btn = driver.findElement(By.cssSelector("button[name='btnK']"));
        System.out.println("Google Search Button's text is: " + g_search_btn.getText());
    }
    @Test
    public void getTagName_Test(){
        g_search_txt = driver.findElement(By.cssSelector("[name='q']"));
        System.out.println("Google Search Text's Tag Name is: <" + g_search_txt.getTagName()+">");

        g_search_btn = driver.findElement(By.cssSelector("[name='btnK']"));
        System.out.println("Google Search Button's Tag Name is: <" + g_search_btn.getTagName()+">");
    }
    @Test
    public void isDisplayed_Test(){
        g_search_txt = driver.findElement(By.cssSelector("[name='q']"));
        System.out.println("Is <Google Search Text> displayed: <" + g_search_txt.isDisplayed()+">");

        g_search_btn = driver.findElement(By.cssSelector("[name='btnG']"));
        System.out.println("Is <Google Search Button> displayed: <" + g_search_btn.isDisplayed()+">");
    }
    @Test
    public void isEnabled_Test(){
        g_search_txt = driver.findElement(By.cssSelector("[name='q']"));
        System.out.println("Is <Google Search Text> Enabled: <" + g_search_txt.isEnabled()+">");

        g_search_btn = driver.findElement(By.cssSelector("[name='btnG']"));
        System.out.println("Is <Google Search Button> Enabled: <" + g_search_btn.isEnabled()+">");
    }
    @Test
    public void isSelected_Test(){
        g_search_txt = driver.findElement(By.cssSelector("[name='q']"));
        System.out.println("Is <Google Search Text> Selected: <" + g_search_txt.isSelected()+">, as Text field is not checkbox, radio button, or options in select.");


        g_search_btn = driver.findElement(By.cssSelector("[name='btnG']"));
        System.out.println("Is <Google Search Button> Selected: <" + g_search_btn.isSelected()+">, as button is not checkbox, radio button, or options in select.");

    }

}

