package scripts;

import org.testng.annotations.Test;

import reuse.Businessfn;

public class TC1 extends Businessfn{
	@Test
	public void tc1_Test() throws Exception 
	{
		search();
		clickFirstITem();
		Thread.sleep(3000);
	}
}
