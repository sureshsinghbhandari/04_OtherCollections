package scripts;

import org.testng.annotations.Test;

import reuse.Businessfn;

public class TC2 extends Businessfn{
  @Test
  public void tc2_Test() throws Exception 
  {
	  search("clothes");
	  clickFirstITem();
	  Thread.sleep(3000);
  }
}
