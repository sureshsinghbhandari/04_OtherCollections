package reuse;

import or.HomePage;
import or.SearchResPage;
import custCommands.ActionDriver;

public class Businessfn extends ActionDriver{
	
	public static void search()
	{
		launchURL("http://www.rightstart.com/");
		type(HomePage.txtSearch, "toys");
		click(HomePage.btnSearch);
		
	}
	public static void search(String data)
	{
		launchURL("http://www.rightstart.com/");
		type(HomePage.txtSearch, data);
		click(HomePage.btnSearch);
		
	}

	public static void clickFirstITem()
	{
		click(SearchResPage.lnkFirstITem);
	}
}
