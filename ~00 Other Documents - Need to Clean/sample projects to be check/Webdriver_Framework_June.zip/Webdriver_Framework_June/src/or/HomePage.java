package or;

import org.openqa.selenium.By;

public class HomePage {
	
	public static By txtSearch = By.id("search");
	public static By btnSearch = By.className("btn_search");

}
