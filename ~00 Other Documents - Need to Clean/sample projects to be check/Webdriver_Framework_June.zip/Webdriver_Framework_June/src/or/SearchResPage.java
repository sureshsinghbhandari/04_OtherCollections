package or;

import org.openqa.selenium.By;

public class SearchResPage {
	
	public static By lnkFirstITem = By.xpath("//li[@class='item first']/div/div/a");
	

}
