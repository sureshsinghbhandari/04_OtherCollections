package custCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import config.StartandStop;

public class ActionDriver extends StartandStop{

	/**
	 * To perform type action on element
	 * @param locator -- get it from OR
	 * @param text --your test data
	 */
	public static void type(By locator, String text)
	{
		driver.findElement(locator).clear();
		driver.findElement(locator).sendKeys(text);
	}
	/**
	 * to perform Click operation on element (link,button,rb,check box)
	 * @param locator --get it from OR
	 */
	public static void click(By locator)
	{
		driver.findElement(locator).click();
	}
	/**
	 * to launch Application URL
	 * @param url --application url
	 */
	public static void launchURL(String url)
	{
		driver.get(url);
	}
	/**
	 * select a value from DropDown by Visible Text
	 * @param locator -- get it from OR
	 * @param visibleText --visible text of DD Value
	 */
	public static void selectByVisibleText(By locator, String visibleText)
	{
		WebElement dd=driver.findElement(locator);
		Select s = new Select(dd);
		s.selectByVisibleText(visibleText);
	}
	/**
	 * perform mouseHover on element
	 * @param locator -- Get it From OR
	 */
	public static void mouseHover(By locator)
	{
		WebElement mo=driver.findElement(locator);
		Actions a = new Actions(driver);
		a.moveToElement(mo).perform();
	}
}
